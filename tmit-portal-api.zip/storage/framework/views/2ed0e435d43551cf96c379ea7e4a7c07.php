<!DOCTYPE html>
<html>
<head>
    <title>Application Rejected</title>
</head>
<body>
    <p>Dear <?php echo e($name); ?>,</p>

    <p>We regret to inform you that your application for admission to our polytechnic has been rejected.</p>

    <p>If you believe this is a mistake or have any questions, please contact the administration office.</p>

    <p>Thank you for your interest.</p>

    <p>Best regards,<br>Polytechnic Admissions</p>
</body>
</html>
<?php /**PATH /home/immanueldev/tmit-portal-api/resources/views/emails/application_rejected.blade.php ENDPATH**/ ?>