<?php
echo "PHP is working!";
